<?php
$apikey = '5bd87d8a52b65';
$starspath = "http://www.myastrologycharts.com/astroservice/";
$enginepath = "http://www.myastrologycharts.com/";
$imagepath = "http://www.myastrologycharts.com/serviceimages";
$enginename = "engineservice.php";
?>
